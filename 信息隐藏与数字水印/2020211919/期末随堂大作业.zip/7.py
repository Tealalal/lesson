import math
from scipy.stats import chi2
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np


plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

img = Image.open("c:/Users/13320/Desktop/2020211919/期末随堂大作业/lena.bmp")
imgc= img.copy()
width=img.size[0]
height = img.size[1]




def psnr(img1, img2):
    img1 = np.float64(img1)
    img2 = np.float64(img2)
    mse = np.mean((img1 / 1.0 - img2 / 1.0) ** 2)
    if mse < 1.0e-10:
        return 100
    PIXEL_MAX = 255.0
    return 20 * math.log10(PIXEL_MAX / math.sqrt(mse))


def generateMatrix(strs):
    ascii=""
    for i in strs:
        ascii +=str(ord(i))
    Matrix = [[]]

    for i in range(8):
        temp = bin(ord(strs[i])).replace('0b','').zfill(8)
        Matrix.append([])
        for j in range(8):
            Matrix[i].append(int(temp[j]))
    return Matrix

def attack(imgcc):
    for i in range(height):
        for j in range(width):
            p = imgcc.getpixel((j, i))
            p = list(p)
            p[2]=p[2] >> 1 << 1
            p[2] += 1
            p = tuple(p)
            imgcc.putpixel((j, i), p)
    return imgcc

def getImgMatrix(imgcc):
    m=[[]]
    for i in range(8):
        m.append([])
        for j in range(8):
            p = imgcc.getpixel((j,i))
            m[i].append(p[2])
    return m

def printMatrix(m):
    result = ''
    for i in range(8):
        for j in range(8):
            result += str(m[i][j]) + ' '
        result += '\n'
    print(result)

if __name__ == '__main__':
    msg=generateMatrix("BUPTSOCS")
    for i in range(8):
        for j in range(8):
           p = img.getpixel((j,i))
           p = list(p)
           p[2]=p[2] >> 1 << 1
           p[2]+=msg[i][j]
           p = tuple(p)
           img.putpixel((j,i),p)

    imga = attack(img.copy())
    imga.save("BlueStgeo1.bmp")

    m = getImgMatrix(imga)

    print("本人学号为2020211919，本人姓名为林于翔，攻击图像最左上角64个像素点的蓝色分量的值如下")
    printMatrix(m)


